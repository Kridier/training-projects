var greenSound = new Audio("./sounds/green.mp3");
var redSound = new Audio("./sounds/red.mp3");
var yellowSound = new Audio("./sounds/yellow.mp3");
var blueSound = new Audio("./sounds/blue.mp3");



function nextSequence(){
    var newRandoNum = Math.floor(Math.random()*4);
    return newRandoNum;
}
nextSequence();
if (nextSequence() === 0){
greenSound.play();
} else if(nextSequence() === 1){
    redSound.play;
} else if(nextSequence() === 2){
    yellowSound.play();
} else if(nextSequence() === 3){
    blueSound.play()
}

console.log(nextSequence())