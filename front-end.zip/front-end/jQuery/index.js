$("h1").css("color", "red");
$( "body" ).on( "keypress", function(event) {
    var characterTyped = String.fromCharCode(event.which)
    console.log( characterTyped );
    $("h1").text(characterTyped);


} );